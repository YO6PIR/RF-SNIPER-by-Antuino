/****************************************************************************************
/******** Graphic User Interface Routine************************************************
****************************************************************************************/
#define X_OFFSET              18
#define MENU_CHANGE_MHZ       0
#define MENU_CHANGE_KHZ       1
#define MENU_MODE_SWR         2
#define MENU_MODE_SNA         3
#define MENU_MODE_VOB         4
#define MENU_SPAN             5
#define PLOTTER               6
#define ACTION_SELECT         1
#define ACTION_DESELECT       2
#define ACTION_UP             3
#define ACTION_DOWN           4

int x1, y1, w, h, x2, y2;
int uiFocus = PLOTTER, Sense = 12, uiSelected = -1;

/********************returns true if the button is pressed*********************
int ENTER_BUTTON(){
  if ( digitalRead(UP_BUTTON)== LOW && digitalRead(DWN_BUTTON)==LOW) return 1;
  else return 0;
}*/
/********************returns true on button release*********************/
int ENTER_BUTTON() {
 if(ENTER)return 1;
 else return 0;
}

/*** NOUA RUTINA care inlocuieste encoderul cu doua taste UP/DOWN *************/
int Up_Down(void) {
  int result = 0;                               //reseteaza valoarea initiala 
  if (SUS) result++;                            //Buton UP apasat= +1
  if (JOS) result--;                            //Buton DOWN apasat= -1
  return result;
}
/********* Rutina optimizată de afișare a frecvenței **************************/
void Frequency2Display(unsigned long f, char *s) {
  char p[11];        // suficient pentru max 10 cifre + terminator
  ultoa(f, p, 10);

  // buffer local pentru zecimale
  a[0] = '\0';
  s[0] = '\0';

  const char *src = p;
  char *dst = s;
  uint8_t len = strlen(p);

  // completează leading spaces pt aliniere
  if (f >= 100000000UL) {            // 100 MHz +
    memcpy(dst, src, 3); dst += 3;
    *dst++ = '.';
    memcpy(dst, src + 3, 3); dst += 3;

    if (!menuON) {
      memcpy(a, src + 6, 2);
      a[2] = '0'; a[3] = '\0';
    }
  } 
  else if (f >= 10000000UL) {        // 10–99 MHz
    *dst++ = ' ';
    memcpy(dst, src, 2); dst += 2;
    *dst++ = '.';
    memcpy(dst, src + 2, 3); dst += 3;

    if (!menuON) {
      memcpy(a, src + 5, 2);
      a[2] = '0'; a[3] = '\0';
    }
  } 
  else if (f >= 1000000UL) {         // 1–9 MHz
    *dst++ = ' '; *dst++ = ' ';
    memcpy(dst, src, 1); dst += 1;
    *dst++ = '.';
    memcpy(dst, src + 1, 3); dst += 3;

    if (!menuON) {
      memcpy(a, src + 4, 2);
      a[2] = '0'; a[3] = '\0';
    }
  } 
  else {                             // <1 MHz
    memcpy(dst, src, 3); dst += 3;
    *dst++ = '.';
    memcpy(dst, src + 3, 3); dst += 3;
  }

  *dst = '\0';
  drawString4x5(42, 2, a);
}

//✅ Versiune corectată (aliniere perfectă a diviziunilor cu linia de bază)


/****************************************************************************************/
void updateHeading() {
  char buf[16];
  char *p = buf;

  // === Prefixul în funcție de mod ===
  switch (mode) {
    case MODE_SWR:  memcpy(p, "SWR ", 4);  p += 4; break;
    case MODE_SNA:  memcpy(p, "SNA ", 4);  p += 4; break;
    case MODE_VOB:  memcpy(p, "VOB ", 4);  p += 4; break;
  }

  // === Afișare frecvență centrală ===
  char num[11];
  ultoa(centerFreq, num, 10);
  uint8_t len = strlen(num);

  const char *src = num;
  if (centerFreq >= 100000000UL) {        // >=100 MHz
    memcpy(p, src, 3); p += 3; *p++ = '.'; memcpy(p, src + 3, 3); p += 3;
  } else if (centerFreq >= 10000000UL) {  // 10–99 MHz
    memcpy(p, src, 2); p += 2; *p++ = '.'; memcpy(p, src + 2, 3); p += 3;
  } else if (centerFreq >= 1000000UL) {   // 1–9 MHz
    memcpy(p, src, 1); p += 1; *p++ = '.'; memcpy(p, src + 1, 3); p += 3;
  } else {                                // <1 MHz
    memcpy(p, src, 3); p += 3; *p++ = '.'; memcpy(p, src + 3, 3); p += 3;
  }

  memcpy(p, "MHz", 3); p += 3; *p = '\0';
  GLCD.DrawString(buf, 0, 0);

  // === Span Frequency ===
  ultoa(spanFreq, num, 10);
  p = buf;

  if (spanFreq < 10000000UL) {
    if (spanFreq > 9999UL) {
      // de ex. 100000 => "10"
      itoa(spanFreq / 10000, buf, 10);
    } else {
      // sub 10kHz => zecimal ex. "0.5"
      *p++ = '0'; *p++ = '.'; *p++ = (char)((spanFreq / 1000) % 10 + '0');
      *p = '\0';
    }
    strcat(buf, "K/DIV");
  } else {
    // >=10 MHz => ex. "1.2M/DIV"
    memcpy(buf, num, 1);
    buf[1] = '.'; buf[2] = num[1]; memcpy(buf + 3, "M/DIV", 5);
    buf[8] = '\0';
  }

  drawString4x5(128 - (strlen(buf) * 5), 0, buf);
}

/******************* Antet pe ecranul principal ******************************/
void antet(){
  GLCD.FillRect(0, 25, 128, 11, WHITE);  
  GLCD.DrawString ("FREQUENCY:", 5,27);
  
  if(centerFreq>=1000000l)GLCD.DrawString("MHz", 109,27);
  else GLCD.DrawString("KHz", 109,27);
  
  Frequency2Display(centerFreq, b);
  GLCD.DrawString(b, 64, 27);
  
  if (uiFocus == MENU_CHANGE_MHZ)  GLCD.DrawRect(63,25,18,11);
  else if (uiFocus == MENU_CHANGE_KHZ) GLCD.DrawRect(87,25,18,11);  
}

/*************************** Calculeaza frecventa actuala de lucru ********************/
void uiFreq(int action){ 
  antet();
  if (!action) return; 
  if (action == ACTION_SELECT) {
      // evidențiere zona selectată
    if (uiFocus == MENU_CHANGE_MHZ) GLCD.InvertRect(63,25,18,11);
    else if (uiFocus == MENU_CHANGE_KHZ) GLCD.InvertRect(87,25,18,11);
      // așteaptă eliberarea butonului
    while(ENTER_BUTTON()) delay(100);    //wait for the button to be released and debounce        
      // bucla de reglaj fin
    while(!ENTER_BUTTON()){              //if button was pressed...          
      int r = analogRead(READING);
      if (r != adc_preview){
        SetOscilators(centerFreq);
        Bargraf();
        adc_preview = r;
      }
      int dir = Up_Down();
      if (dir==0)continue;
      //scadere frecventa
      if (dir < 0 && centerFreq > 440000l){
        if (uiFocus == MENU_CHANGE_MHZ) {
          centerFreq += (centerFreq > 2000000UL) ? 1000000L * dir : 10000L * dir;
        } else if (uiFocus == MENU_CHANGE_KHZ && centerFreq >= 1010000UL) {
          centerFreq += 10000L * dir;
        }
        if (centerFreq < 4000000000l && centerFreq > 150000000l) centerFreq = 150000000l;
      delay(100);
      }
      else if (dir > 0 && centerFreq < 499000000l){
        if (uiFocus == MENU_CHANGE_MHZ) {
          centerFreq += (centerFreq < 1000000UL) ? 10000L * dir : 1000000L * dir;
        } else if (uiFocus == MENU_CHANGE_KHZ && centerFreq >= 1000000UL) {
          centerFreq += 10000L * dir;
        }
      delay(100);
      }
    // else  continue;  
     antet();
    if (uiFocus == MENU_CHANGE_MHZ) GLCD.InvertRect(63,25,18,11);
    else if (uiFocus == MENU_CHANGE_KHZ) GLCD.InvertRect(87,25,18,11);
       }
         while(ENTER_BUTTON()){ delay(200);}//asteapta relazarea butonului
         
    uiSelected = -1;
    GLCD.FillRect(63,25,18,11,WHITE);
    GLCD.FillRect(87,25,18,11,WHITE);
    ResetMainScreen();
  }  
}
/*************************** Selectie MODE SWR ****************************/
void uiSWR(int action){
  GLCD.FillRect(6,37,22,12, WHITE);
  GLCD.DrawString("SWR", 9, 40);

  if (action == ACTION_SELECT){
    mode = MODE_SWR;
    uiPWR(0);                                                 //dezactiveaza MODE_SNA
    uiSNA(0);                                                 //dezactiveaza MODE_VOB
    delay(200);
  }  
  if (uiFocus == MENU_MODE_SWR) GLCD.DrawRect(6,37,22,12);    //focus pe SWR_icon
  if (mode == MODE_SWR) GLCD.InvertRect(8,39,18,8);           //invert color SWR_icon
  SetOscilators(centerFreq);
  Bargraf();
}

/*******************Selectie MODE PWR ************************************/
void uiPWR(int action){
  GLCD.FillRect(30,37,22,12, WHITE);    
  GLCD.DrawString("SNA", 33, 40);

  if (action == ACTION_SELECT){
    mode = MODE_SNA;
    uiSWR(0);                                   //dezactiveaza MODE_SWR
    uiSNA(0);                                   //dezactiveaza MODE_VOB
    delay(200);
  }
  if (uiFocus == MENU_MODE_SNA) GLCD.DrawRect(30,37,22,12);
  if (mode == MODE_SNA)  GLCD.InvertRect(32,39,18,8);
  SetOscilators(centerFreq);
  Bargraf();
}

/************************* Selectie MODE SNA *******************************/
void uiSNA(int action){
  GLCD.FillRect(54,37,22,12, WHITE);
  GLCD.DrawString("VOB", 57, 40);

  if (action == ACTION_SELECT){
    mode = MODE_VOB;
    uiSWR(0);
    uiPWR(0);
    delay(200);
  }
  if (uiFocus == MENU_MODE_VOB)  GLCD.DrawRect(54,37,22,12);
  if (mode == MODE_VOB) GLCD.InvertRect(56,39,18,8);
  SetOscilators(centerFreq);
  Bargraf();
}

/*************** Rutina Modificare Span-INTERVAL *****************/
void uiSpan(int action){
  GLCD.FillRect(56, 49, 29, 13, WHITE);
  if (spanFreq >= 1000000l) sprintf(b, "Interval: %3ldM", spanFreq/1000000l);
  else  sprintf(b, "Interval: %3ldK", spanFreq/1000l);  
  GLCD.DrawString(b, 0,52);

  if (uiFocus == MENU_SPAN)  GLCD.DrawRect(56, 49, 29, 13);
  if (action == ACTION_SELECT){      
    GLCD.InvertRect(58, 51, 25, 9);                           //invert the selection
  
    while(ENTER_BUTTON());
    delay(200);
    
     
    while(!ENTER_BUTTON()){                                   //wait again for the button to be pressed    
      int i = Up_Down(); 
      
      if (selectedSpan > 0 && i > 0){
        selectedSpan--;
        spanFreq = SpanNum[selectedSpan];    
        if(spanFreq > centerFreq*2) spanFreq=centerFreq*2;
        delay(200);
      }
      else if (selectedSpan < MAX_SpanNum && i < 0){
        selectedSpan++;
        spanFreq = SpanNum[selectedSpan];       
        if(spanFreq > centerFreq*2) spanFreq=centerFreq*2;
        delay(200);
      }
      else 
        continue;
         
      GLCD.FillRect(56, 49, 29, 13, WHITE);
      
      if (spanFreq >= 1000000l) sprintf(b, "Interval: %3ldM", spanFreq/1000000l);
      else sprintf(b, "Interval: %3ldK", spanFreq/1000l);
      GLCD.DrawString(b, 0,52);
      GLCD.InvertRect(58, 51, 26, 10);
    }
    while(ENTER_BUTTON()){ delay(200);}//asteapta relazarea butonului
       
      GLCD.FillRect(56, 49, 29, 13, WHITE);
      if (spanFreq >= 1000000l) sprintf(b, "Interval: %3ldM", spanFreq/1000000l);
      else sprintf(b, "Interval: %3ldK", spanFreq/1000l);
      GLCD.DrawString(b, 0,52);
      GLCD.DrawRect(56, 49, 29, 13);
  }
}
/********************** MODE PLOT grafic grid scanning **********************/
void uiPlot(int action){
  GLCD.FillRect(90, 42, 37,20, WHITE);                  //marcheaza cu chenar alb
  GLCD.DrawRect(90, 42, 37,20);                         //deseneaza chenar
  GLCD.DrawString("SCAN", 98, 49);                      //scrie "PLOT" in chenar

  if (uiFocus == PLOTTER) GLCD.DrawRect(92, 44, 33, 16);
  if(spanFreq > centerFreq*2) spanFreq=centerFreq*2;
  if (action == ACTION_SELECT){
    if (mode == MODE_SWR) plotVSWR();
    else plotPower();
    ResetMainScreen();
  }
}

/*******************************************************************/
void uiMessage(int id, int action){
  switch(id){
    case MENU_CHANGE_MHZ:
    case MENU_CHANGE_KHZ:
      uiFreq(action);
      break;
    case MENU_MODE_SWR:
      uiSWR(action);
      break;
    case MENU_MODE_SNA:
      uiPWR(action);
      break;
    case MENU_MODE_VOB:
      uiSNA(action);
      break;
    case MENU_SPAN:
      uiSpan(action);
      break;
    case PLOTTER:
      uiPlot(action);
      break;
    default:
    return;
  }
}

/****************** Schimbarea meniului din ecranul principal ******/
void MainMenu(){
  int i = Up_Down();                             //citeste tastele     

  if (ENTER_BUTTON()){
    if (uiSelected == -1)  uiMessage(uiFocus, ACTION_SELECT);
    if (uiSelected != -1)  uiMessage(uiFocus, ACTION_DESELECT); 
  }
  
  if (i == 0) return;  
  if (i > 0 && Sense < 12) Sense += i;
  if (i < 0 && Sense >= 0) Sense += i;      
  if (uiFocus != Sense/2){
    int adc_preview = uiFocus;
    uiFocus = Sense/2;           
    if(uiFocus>6)uiFocus=6;
    uiMessage(adc_preview, 0);
    uiMessage(uiFocus, 0);
  }
}

void DrawBatterySymbol(int x, int y, float Vbat) {
    const float Vmax = 4.05;       // tensiunea maximă
    const float Vmin = 3.3;       // tensiunea minimă vizibilă
    const int width_full = 20;    // lungimea originală
    const int height_full = 8;    // înălțimea originală
    const int tip_full = 2;       // cap baterie original

    // scădere dimensiuni la 3/4
    int width = 14;    // 15 px
    int height = 6;  // 6 px
    int tip = 1;        // 1 px

    // limitare tensiune între Vmin și Vmax
    if (Vbat < Vmin) Vbat = Vmin;
    if (Vbat > Vmax) Vbat = Vmax;

    // determinare nivel sferturi (0..4)
    int level = (int)(((Vbat - Vmin) / (Vmax - Vmin)) * 4.0 + 0.1);
    if (level > 4) level = 4;

    // 1. Desen contur baterie
    GLCD.DrawRect(x, y, width, height, WHITE);                      // contur corp
    GLCD.FillRect(x + width, y + height / 4, tip, height / 2, WHITE); // cap baterie

    // 2. Umple sferturi interior, păstrând 1 px spațiu față de contur
    int cellWidth = width / 4;
    for (int i = 0; i < level; i++) {
        GLCD.FillRect(
            x + i * cellWidth + 2,    // +1 px margine stânga
            y + 2,                     // margine sus
            cellWidth-2 ,             // lățime redusă pentru margini stânga/dreapta
            height - 4    ,                // înălțime redusă pentru margini sus/jos
            WHITE
        );
    }
}
/***********************************************************************************/
void ResetMainScreen() {
    int esc = analogRead(ESC_BUTON);
    float Vbat = esc * 5.0 / 1023.0;
  
    // 1. Bara titlu: alb pe negru
    GLCD.FillRect(0, 0, 128, 10, WHITE);  // fundal alb
    strcpy(b, " RF-Snipper 2.1");
    GLCD.DrawString(b, 1, 2);
    GLCD.InvertRect(0, 0, 128, 10);       // inversare fundal/text

    // 2. Simbol baterie desenat DUPĂ inversare, astfel apare corect
    DrawBatterySymbol(107, 2, Vbat);

    // 3. Rest UI
    Bargraf();
    uiFreq(0);
    uiSWR(0);
    uiPWR(0);
    uiSNA(0);
    uiSpan(0);
    uiPlot(0);

    menuON = true;
}
void Bargraf() {
    char buf[16];
    int reading = analogRead(READING);
    float levelPercent = 0.0;

    // === Parametri grafici comuni ===
    const int yBase = 21;            // linia de bază
    const int barHeight = 4;         // înălțimea acului
    const int numDivs = 9;           // 10 diviziuni principale
    const int linesPerDiv = 8;       // lățimea totală pentru calcul
    const int barWidth = numDivs * linesPerDiv; // 72 px
    const int xEnd = 123;
    const int xStart = xEnd - barWidth;

    // Curățăm zona bargrafului
    GLCD.FillRect(0, 11, 128, 12, WHITE);

    float divSpacing = (float)barWidth / numDivs;

    // === MOD SWR ===
    if (mode == MODE_SWR) {
        float vswr = swrCalculate();
        int vswr10 = int(vswr * 10);

        if (vswr > 9.9 || vswr < 0)
            sprintf(buf, "SWR:>>>");
        else
            sprintf(buf, "SWR:%d.%01d", vswr10 / 10, vswr10 % 10);

        if (vswr < 0.0) vswr = 0.0;
        if (vswr > 9.0) vswr = 9.0;
        levelPercent = (vswr / 9.0) * 100.0;

        GLCD.DrawString(buf, 0, yBase - 6);

        // Linie de bază
        GLCD.FillRect(xStart, yBase, barWidth, 1, BLACK);

        // Diviziuni principale + intermediare
        for (int i = 0; i <= numDivs; i++) {
            int x = xStart + (int)(i * divSpacing + 0.5);
            int divHeight =2;// (i == 0 || i == numDivs) ? 6 : 2;
            GLCD.DrawLine(x, yBase, x, yBase - divHeight, BLACK);

            // Diviziuni intermediare
            if (i < numDivs) {
                int xHalf = x + (int)(divSpacing / 2 + 0.5);
                GLCD.DrawLine(xHalf, yBase, xHalf, yBase - 1, BLACK);
            }
        }

        // Cifre principale 2,4,6,8
        drawString4x5(xStart + divSpacing * 1 - 2, yBase - 8, "1");
        drawString4x5(xStart + divSpacing * 3 - 2, yBase - 8, "3");
        drawString4x5(xStart + divSpacing * 5 - 2, yBase - 8, "5");
        drawString4x5(xStart + divSpacing * 7 - 2, yBase - 8, "7");
         drawString4x5(xStart + divSpacing * 9 - 2, yBase - 8, "9");

        // Acul indicator (2px grosime, 9px înălțime) cu contur alb
        int barLength = (int)((levelPercent / 100.0) * barWidth);
        int xNeedle = xStart + barLength;
       
        //al doilea ac mai mic
        GLCD.FillRect(xNeedle-1, yBase - 2, 2, 4, BLACK);          // corp negru
        GLCD.DrawRect(xNeedle-1, yBase - 2, 2, 4, WHITE);         // contur alb
        //primul ac deasupra
        GLCD.DrawLine(xNeedle, yBase - 8, xNeedle,yBase-2, BLACK);          // corp negru
    }

    else { // MOD PWR
        int dbm = reading / 5 + dbmOffset;
        sprintf(buf, "%ddBm", dbm);

        if (dbm < -68) dbm = -68;
        if (dbm > 0) dbm = 0;
        levelPercent = ((float)(dbm + 68) / 68.0) * 100.0;

        GLCD.DrawString(buf, 0, yBase - 6);

        // Linie de bază
        GLCD.FillRect(xStart, yBase, barWidth, 1, BLACK);

        // Diviziuni principale + intermediare
        for (int i = 0; i <= numDivs; i++) {
            int x = xStart + (int)(i * divSpacing + 0.5);
            int divHeight = (i == 0) ? 6 : 2;
            GLCD.DrawLine(x, yBase, x, yBase - divHeight, BLACK);

            if (i < numDivs) {
                int xHalf = x + (int)(divSpacing / 2 + 0.5);
                GLCD.DrawLine(xHalf, yBase, xHalf, yBase - 1, BLACK);
            }
        }

        // Cifre principale 50,40,30,20,0
        drawString4x5(xStart + divSpacing * 1 - 4, yBase - 8, "60");
        drawString4x5(xStart + divSpacing * 3 - 4, yBase - 8, "45");
        drawString4x5(xStart + divSpacing * 5 - 4, yBase - 8, "30");
        drawString4x5(xStart + divSpacing * 7 - 4, yBase - 8, "15");
        drawString4x5(xStart + divSpacing * 9 - 2, yBase - 8, "0");

        // Acul indicator (2px grosime, 9px înălțime) cu contur alb
        int barLength = (int)((levelPercent / 100.0) * barWidth);
        int xNeedle = xStart + barLength;
        //al doilea ac mai mic
        GLCD.FillRect(xNeedle-1, yBase - 2, 2, 4, BLACK);          // corp negru
        GLCD.DrawRect(xNeedle-1, yBase - 2, 2, 4, WHITE);         // contur alb
        //primul ac deasupra
        GLCD.DrawLine(xNeedle, yBase - 8, xNeedle,yBase-2, BLACK);          // corp negru
    }
}
