  #define Y_OFFSET 14                         //de unde incepe desenarea graficului fata de top
  int16_t  plot_readings[128];
  unsigned long   f, f1, f2, stepSize;
  
/************** Functia de calcul SWR imprumutata dela RF-Sniper3 ****************/
float swrCalculate(){
      volts=  (float(analogRead(READING)) * 5.0 )/ 1023.0;
         working_dBm = (40 * volts) - 85;             //valori intre -85.0 dBm si +15.0 dBm pt 0-5V slope 
         working_dBm += swrOffset_calibrated;
         float v2 = pow(10, working_dBm/20);
         float r_ant = 51/((1/(v2+0.5))-1);
         float swr = r_ant / 51;
    return swr;     
}
/*********** Calculeaza frecventa afisata pe ecran *********************/  
  int freq2screen(unsigned long freq){
    unsigned long f1, f2, hz_per_pixel;
    hz_per_pixel = spanFreq / 100;
    f1 = centerFreq - spanFreq/2;
    return (int)((freq - f1)/hz_per_pixel) + X_OFFSET;
}

/************ Scaleaza valoarea dBm afisata pe grafic ********************/
  int pwr2screen(int y){
  return  ((-y*11)/16) + Y_OFFSET;    //factor 0.6875
}

/*********** Scaleaza valoarea VSWR afisata pe grafic ********************/
int vswr2screen(int y){
  if (y >= 100 || y<1) y = 99;
  return ((100-y)/2)+Y_OFFSET-1;
}

/******* Deseneaza cursorul Sageata cu varful in jos pe ecran ****/
void updateCursor(int current_pos){
  GLCD.DrawLine(current_pos+X_OFFSET-2, 8, current_pos + X_OFFSET+2, 8);
  GLCD.DrawLine(current_pos+X_OFFSET-3, 8, current_pos + X_OFFSET, 11);
  GLCD.DrawLine(current_pos+X_OFFSET+3, 8, current_pos + X_OFFSET, 11);
 }
 
/***************** Afiseaza valoarea dBm a cursorului in antet ************/
void powerHeading(int current_pos){
  e[0]=0;
  GLCD.FillRect(0,0,127,11, WHITE);
  if(centerFreq<=440000l) current_pos -= 1;      
  Frequency2Display(f1 + (stepSize * current_pos), b);
      
  if((f1+(stepSize*current_pos))<1000000l)strcat(e, "KHz");else strcat(e, "MHz");
  if(centerFreq>=440000l)  centerFreq=(f1 + (stepSize * current_pos));                //update frecventa la pozitia cursorului
  else centerFreq=440000l;
   
  /************ Ajusteaza SPAN interval automat *************************/
  if(centerFreq <= spanFreq/2) if(selectedSpan<MAX_SpanNum )selectedSpan++; 
  spanFreq = SpanNum[selectedSpan];  
  /******************************************************************/  
  GLCD.DrawString(b, 0, 0);
  GLCD.DrawString(e, 57, 0);
    
  if (mode == MODE_SWR){
    if(plot_readings[current_pos] > 99 || plot_readings[current_pos] < 0) sprintf (b, "SWR:>>>");  
    else sprintf (b, "SWR:%d.%01d", plot_readings[current_pos]/10,plot_readings[current_pos] % 10);
  }
  else  sprintf(b, "%ddBm", plot_readings[current_pos]);
  
  GLCD.DrawString(b, 80, 0); /*afiseaza valoarea citita de cursor*/
  updateCursor(current_pos);  /*deseneaza cursorul actualizat pe ecran*/ 
}

/****************************** Afiseaza Grafic VSWR ***********************************************/
 void plotVSWR(){
  menuON = false;
  int x, y, pwr;
  char p[20]; 
 
    while(ENTER_BUTTON())              //asteapta relaxarea tastei <ENTER> daca a fost apasata
    delay(100);

    GLCD.ClearScreen(); 
    GLCD.FillRect(0, 0, 128, 10, WHITE);
     
    while (!ENTER_BUTTON()){           //daca nu se mai apasa tasta <ENTER>...
    int current_pos = 50;       //seteaza cursorul la mujlocul scalei  
    updateHeading(); 

 /***** draw the horizontal grid *******************/
  for (y = 0; y <= 100; y += 20){
    for (x = X_OFFSET; x <= 100+ X_OFFSET; x += 2)
    GLCD.SetDot(x,vswr2screen(y+1),BLACK);
  }  
  f1 = centerFreq - (spanFreq/2);
  if (f1 < 0) f1 = 0;  
  f2 = f1 + spanFreq;
  
  /******* Draw Vertical Grids *******************/
  for (f = f1; f <= f2; f += spanFreq/10){
    for (y =0; y <= 50; y += 2)
    GLCD.SetDot(freq2screen(f),y+Y_OFFSET,BLACK);
  }
  /******* Draw Markers SWR pe lateral ***********/
  for (y = Y_OFFSET; y < 100 + Y_OFFSET; y += 20){
    itoa(y/10, p, 10);
    strcat(p, "-");
    GLCD.DrawString(p, 6, vswr2screen(y)-1);
  }  

  f1 = centerFreq - (spanFreq/2);
  f2 = f1 + spanFreq;
  stepSize = (f2 - f1)/100;
  int i = 0, vswr_reading;

/*************** TRASEAZA GRAFICUL VSWR PE ECRAN *********************/
  for (f = f1; f < f2; f += stepSize){
    SetOscilators(f);
    int esc = analogRead(ESC_BUTON);   //citeste butonul ESC
    if(ESC){
      SINGLE=false;AUTO=true;
      GLCD.ClearScreen();
     // delay(200);
      ResetMainScreen();
      return;
      }
    if (ENTER_BUTTON()|| Up_Down() || SINGLE) AUTO=false;                      //daca se apasa tasta <ENTER> dezactiveaza modul AUTO... 
    if(!AUTO || SINGLE) updateCursor(current_pos);                            //...si deseneaza cursorul pe ecran
    
     GLCD.FillRect(104, 7, 24, 5, WHITE);
     if (AUTO)drawString4x5(104, 7, "AUTO  ");
     if (!AUTO || SINGLE)drawString4x5(99, 7, "SINGLE");    
    
    delay(20);

    plot_readings[i] = int(swrCalculate()*10);;

    if (i == 0) GLCD.SetDot(freq2screen(f),vswr2screen(vswr_reading),BLACK);
    else GLCD.DrawLine(i + X_OFFSET-1, vswr2screen(plot_readings[i-1]), i + X_OFFSET, vswr2screen(plot_readings[i])); 
    i++;
  }
/********************* Noua rutina de scanare manuala ****************************************/
  do{
    i = Up_Down();delay(50);                       //verifica tastele <UP><DOWN>
    if ((i < 0 && current_pos + i >= 0) ||          //daca oricare tasta este apasata...
      (i > 0 && current_pos + i <= 100)){
        current_pos += i;                           //modifica pozitia cursorului
        powerHeading(current_pos);                  //si update valoare frecventa
      }
    if (ENTER_BUTTON()){
      AUTO=true; 
      SINGLE=true;                       //daca se re-apasa tasta <ENTER> activeaza modul SINGLE 
    }

/*daca se apasa tasta [ESC] iese din modul scanare in meniul principal*/    
    int esc = analogRead(ESC_BUTON);                //citeste butonul ESC
    if(ESC) {
      SINGLE = false; 
      AUTO = true;
      GLCD.ClearScreen();
      ResetMainScreen();  
      return;
    }
     
} while(!AUTO);                                     //repeta scanarea manuala pana cand AUTO este activata
    while (ENTER_BUTTON()) delay(50);
    GLCD.ClearScreen(); 
  }
}

/******************************** Grafic PLOT PWR **********************************/
void plotPower(){

  menuON=false;
  int x, y, pwr;
  char p[20];  

    while(ENTER_BUTTON()){              //asteapta relaxarea tastei <ENTER> daca a fost apasata
    delay(100);}

    GLCD.ClearScreen(); 
    GLCD.FillRect(0, 0, 128, 10, WHITE);
     
    while (!ENTER_BUTTON()){           //daca nu se mai apasa tasta <ENTER>...
    int current_pos = 50;       //seteaza cursorul la mujlocul scalei  
    updateHeading(); 

  /*afiseaza cifrele de la 15 la 75 dB pe lateral grafic*/
  for(int y=0;y<=4;y++ ){
   if(y==0)sprintf(b, "  %d", y*15);else sprintf(b, "-%d", y*15);
   if(y>=0) GLCD.DrawString(b, 0, Y_OFFSET-2+(y*10));
  }
  /*draw the horizontal grid scale*/
  for (y = 0; y <= 100; y += 20){   
    for (x = X_OFFSET; x <= 100+ X_OFFSET; x += 2)
    GLCD.SetDot(x,vswr2screen(y+1),BLACK);
  }  
  /*draw the vertical grid scale*/
  f1 = centerFreq - (spanFreq/2);
  if (f1 < 0) f1 = 0;
  f2 = f1 + spanFreq;
  for (f = f1; f <= f2; f += spanFreq/10){
    for (y =0; y <= 50; y += 2)
    GLCD.SetDot(freq2screen(f),y+Y_OFFSET,BLACK);    //deseneaza GRID
  }
  f1 = centerFreq - (spanFreq/2);
  f2 = f1 + spanFreq;
  stepSize = (f2 - f1)/100;
  int dir = 0, vswr_reading;

/***************** DESENEAZA GRAFICUL POWER PE ECRAN *************************/
  for (f = f1; f < f2; f += stepSize){
    SetOscilators(f);
    int esc = analogRead(ESC_BUTON);   //citeste butonul ESC
    if(ESC){
      SINGLE=false;AUTO=true;
      GLCD.ClearScreen();
      ResetMainScreen();
      return;
    }
    if (ENTER_BUTTON()|| Up_Down() || SINGLE) AUTO=false;                      //daca se apasa tasta <ENTER> dezactiveaza modul AUTO... 
    if(!AUTO || SINGLE) updateCursor(current_pos);                            //...si deseneaza cursorul pe ecran

     GLCD.FillRect(104, 7, 24, 5, WHITE);
     if (AUTO)drawString4x5(104, 7, "AUTO  ");
     if (!AUTO || SINGLE)drawString4x5(99, 7, "SINGLE");    

    /******************** now take the readings***********************************/
    if(mode==MODE_VOB)delay(10);else delay(5); 
    
   int r = analogRead(READING)/5 + dbmOffset;
   
    plot_readings[dir] = r;
    if (dir == 0)  GLCD.SetDot(X_OFFSET, pwr2screen(plot_readings[dir]),BLACK);
    else GLCD.DrawLine(dir + X_OFFSET-1, pwr2screen(plot_readings[dir-1]), dir + X_OFFSET, pwr2screen(plot_readings[dir])); 
    dir++;
  }
 /********************* Noua rutina de scanare manuala ****************************************/
  do{
    dir = Up_Down();delay(50);                       //verifica tastele <UP><DOWN>
    if ((dir < 0 && current_pos + dir >= 0) ||          //daca oricare tasta este apasata...
      (dir > 0 && current_pos + dir <= 100)){
        current_pos += dir;                           //modifica pozitia cursorului
      
        powerHeading(current_pos);                  //si update valoare frecventa
      }
    if (ENTER_BUTTON()){
      AUTO=true; 
      SINGLE=true;                       //daca se re-apasa tasta <ENTER> activeaza modul SINGLE 
    }
/*daca se apasa tasta [ESC] iese din modul scanare in meniul principal*/    
    int esc = analogRead(ESC_BUTON);                //citeste butonul ESC
    if(ESC) {
      SINGLE=false;AUTO=true;
      GLCD.ClearScreen();
      ResetMainScreen();
      return;
    }     
} while ( !AUTO);                                     //repeta scanarea manuala pana cand AUTO este activata
    while (ENTER_BUTTON()){ delay(50);}
    GLCD.ClearScreen(); 
  }
}
