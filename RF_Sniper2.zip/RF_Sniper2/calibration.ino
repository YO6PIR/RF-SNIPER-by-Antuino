/********************* MENIUL DE CALIBRARE*******************************/
void drawCalibrationMenu(int selection){
GLCD.ClearScreen();
  GLCD.FillRect(0, 0, 128, 64, WHITE);
  GLCD.DrawString("*** SETTINGS MENU ***", 0, 0);
  GLCD.DrawString(" Si5351 CLOCK ADJUST ", 0, 15);
  GLCD.DrawString(" SWR RETURN LOSS ADJ.", 0, 30);
  GLCD.DrawString(" 0dBm OFFSET ADJUST  ", 0, 45);

  if (selection == 0)  GLCD.DrawRect(0,10,127,15);
  if (selection == 1)  GLCD.DrawRect(0,25,127,15);
  if (selection == 2)  GLCD.DrawRect(0,40,127,15);
}

/*******************************************************************************/
void SettingsMenu(){
  int i, select_item = 0;
// Lambda locală pentru desenarea meniului 
auto drawCalibrationMenu = [](int selection) { 
  GLCD.ClearScreen(); 
  GLCD.FillRect(0, 0, 128, 64, WHITE); 
  GLCD.DrawString("*** SETTINGS MENU ***", 0, 0); 
  GLCD.DrawString(" Si5351 CLOCK ADJUST ", 0, 15); 
  GLCD.DrawString(" SWR RETURN LOSS ADJ.", 0, 30); 
  GLCD.DrawString(" 0dBm OFFSET ADJUST ", 0, 45); 
  if (selection == 0) GLCD.DrawRect(0,10,127,15); 
  if (selection == 1) GLCD.DrawRect(0,25,127,15); 
  if (selection == 2) GLCD.DrawRect(0,40,127,15); 
  };

  drawCalibrationMenu(select_item);

  while(ENTER_BUTTON()) delay(100);

  for(;;){
    drawCalibrationMenu(select_item);
  
    while(!ENTER_BUTTON()){
     /*daca se apasa tasta [ESC] iese din modul scanare in meniul principal*/    
    int esc = analogRead(ESC_BUTON);                //citeste butonul ESC
    if(ESC) {
      GLCD.ClearScreen();
      GLCD.DrawString("Booting...", 40, 25);
      delay(1000);
      setup();
      return;
    }      
      i = Up_Down();                                //citeste tastele UP/DWN
      
      if(i > 0 && select_item < 2){
        select_item += 1 *i ;
        drawCalibrationMenu(select_item);
      }
      else if (i < 0 && select_item >0){
        select_item += 1 *i; 
        drawCalibrationMenu(select_item);
      }
      delay(50);
    }  
    while(ENTER_BUTTON()) delay(100);    
    if (select_item==0) calibrateClock();
    else if (select_item==1)calibrateSWR();
    else if (select_item==2)Calibrate_dBmOffset();
  }
}

/*********** Rutina de calibrare XTALL Frequency Clock *********************/
int calibrateClock(){
  bool change=false;
  int Sense = 0;
  int32_t adc_preview_calibration;
  char  *p;

  GLCD.ClearScreen();
  GLCD.DrawString("1.Monitor RF Output", 0, 0);
  GLCD.DrawString(" port on 10 MHz freq.", 0, 10);
  GLCD.DrawString("2.Tune to zerbeat and", 0, 20);
  GLCD.DrawString("3. Click to Save", 0, 30);

  GLCD.DrawString("Save", 96, 45);
  GLCD.DrawRect(92,40,32,20);
  GLCD.DrawString("EXIT", 4, 45);  
  GLCD.DrawRect(0,40,32,20);

  while (ENTER_BUTTON())  active_delay(100);

  si5351aSetFrequency_clk0(10000000l);  
  ltoa(xtal_freq_calibrated - 27000000l, c, 10);
  
  GLCD.FillRect(40,40,50,20, WHITE);
  GLCD.DrawString(c, 44, 45);     
  
  while (!ENTER_BUTTON()){                        /* Pana nu se apasa tasta ENTER...*/
       /*daca se apasa tasta [ESC] iese din modul scanare in meniul principal*/    
    int esc = analogRead(ESC_BUTON);                //citeste butonul ESC
    if(ESC) {
      GLCD.ClearScreen();
      GLCD.DrawString("Exit without Saved", 10, 25);
      active_delay(1000);
      return;
    }  
    
    Sense = Up_Down();            

    if (Sense > 0) {
      change=true;
      xtal_freq_calibrated += 10;
    }
    else if (Sense < 0) {
      change=true;
      xtal_freq_calibrated -= 10;
    }
    else continue; //don't update the frequency or the display

    si5351aSetFrequency_clk0(10000000l);  
    ltoa(xtal_freq_calibrated - 27000000l, c, 10);
    
    GLCD.FillRect(40,40,50,20, WHITE);
    GLCD.DrawString(c, 44, 45);  
  }

  while (ENTER_BUTTON()) active_delay(100);
  
  GLCD.ClearScreen();
  GLCD.DrawString("Calibration Saved", 0, 25);

  if(change) EEPROM.put(MASTER_CAL_EEP_ADDR, xtal_freq_calibrated);
  delay(2000);
}
/********************************************************************************/
  void Calibrate_dBmOffset(){
    mode=MODE_VOB;
    SetOscilators(14000000);

  GLCD.ClearScreen();
  GLCD.DrawString("Connect the RF IN-OUT ", 0, 0);
  GLCD.DrawString("ports and adjust the  ", 0, 10);
  GLCD.DrawString("measured values= 0dBm", 0, 20);
  GLCD.DrawString("Press SAVE to memory. ", 0, 30);

  GLCD.DrawString("SAVE", 96, 45);
  GLCD.DrawRect(92,40,32,20);
  GLCD.DrawString("EXIT", 4, 45);  
  GLCD.DrawRect(0,40,32,20);

    
   do {    
    /*daca se apasa tasta [ESC] iese din modul scanare in meniul principal*/    
    int esc = analogRead(ESC_BUTON);                //citeste butonul ESC
    if(ESC) {
      GLCD.ClearScreen();
      GLCD.DrawString("Exit without Saved", 10, 25);
      active_delay(1000);
      return;
    }         
    active_delay(50);  //wait for a button down
    int Sense = Up_Down();            

    if (Sense > 0) {
      dbmOffset += 1*Sense;
    }
    else if (Sense < 0) {
      dbmOffset += 1* Sense;
    }
    else continue; //don't update the frequency or the display
    
    GLCD.FillRect(40,40,50,20, WHITE);    
    dtostrf(dbmOffset,5,0,c);           
    GLCD.DrawString(c, 48, 52); 

    sprintf(c, "%ddBm", analogRead(READING)/5 + dbmOffset);
    GLCD.DrawString(c, 43,42);  

    }while(!ENTER_BUTTON());
  EEPROM.put(DBM_OFFSET_ADDR, dbmOffset);
  
  GLCD.ClearScreen();
  GLCD.DrawString("Saved!",10,25);
  delay(1000);
  }

/********** Rutina Calibrare SWR OFFSET *************************/
int calibrateSWR(){
  mode=MODE_SWR;
  centerFreq = 14000000;
  SetOscilators(centerFreq);
  
  GLCD.ClearScreen();  
  GLCD.DrawString   ("Conect R>=300 Ohms to", 0, 0);
  GLCD.DrawString   ("input and check SWR. ", 0, 10);
  GLCD.DrawString   (" UP/DWN adjust value ",  0, 20);

  GLCD.DrawString("SAVE", 96, 45);
  GLCD.DrawRect(92,40,32,20);
  GLCD.DrawString("EXIT", 4, 45);  
  GLCD.DrawRect(0,40,32,20);

    GLCD.FillRect(40,40,50,24, WHITE);    
    dtostrf(swrOffset_calibrated,5,1,c);           
    GLCD.DrawString(c, 34, 52);  
    GLCD.print("dBm");
   
  do {    
    /*daca se apasa tasta [ESC] iese din modul scanare in meniul principal*/    
    int esc = analogRead(ESC_BUTON);                //citeste butonul ESC
    if(ESC) {
      GLCD.ClearScreen();
      GLCD.DrawString("Exit without Saved", 10, 25);
      active_delay(1000);
      return;
    }         
    active_delay(50);  //wait for a button down
    int Sense = Up_Down();            

    if (Sense > 0) {
      swrOffset_calibrated += 0.1;
    }
    else if (Sense < 0) {
      swrOffset_calibrated -= 0.1;
    }
    else continue; //don't update the frequency or the display
    
    GLCD.FillRect(40,40,50,20, WHITE);    
    dtostrf(swrOffset_calibrated,5,1,c);           
    GLCD.DrawString(c, 34, 52);GLCD.print("dBm");  

    int vswr_reading= int(swrCalculate()*10);
    if(vswr_reading>99 || vswr_reading<0) sprintf (c, "SWR:>>>");          
    else sprintf (c, "SWR:%d.%01d", vswr_reading/10, vswr_reading%10);  
    GLCD.DrawString(c, 43,42);  

    }while(!ENTER_BUTTON());
  EEPROM.put(SWR_OFFSET_ADDR, swrOffset_calibrated);
  
  GLCD.ClearScreen();
  GLCD.DrawString("Saved!",10,25);
  delay(1000);
}
