/*########################################################################    
#       ___    ___  _______    ______    _______   ___ _______           #
#       \   \ /  / /   __   \ /   ___)  |    __  \|   |    __  \         #
#        \   /  / |   |  |   |   |____  |   |__)  |   |   |__)  |        #
#         \    /  |   |  |   |    ___  \|    ____/|   |       _/         # 
#         |   |   |   |__|   |   (___)  |   |     |   |   |\   \         #
#         |___|    \_______ / \________/|___|     |___|___| \___\        # 
#                                                                        #   
##########################################################################    
           
 *             RF-SNIPPER Ver.2 - 2021 (Revizuit in oct.2025)
 *                  https://www.qsl.net/yo6pir/snipper
 *    Processor:    ATMEGA 328p - Arduino Pro or PRO-MINI
 *    VFO-DDS:      Si5351
 *    Display:      KS0107- paralel
 *    Based on      Antuino Project
 *    ALL Commands  4pcs Soft-Tuch-Buttons 
********************************************************************************/
#include <glcd.h>
#include <fonts/allFonts.h>
#include <Wire.h>
#include <EEPROM.h>
/* I/O ports to read the tuning mechanism */
#define UP_BUTTON              (A1)
#define DWN_BUTTON             (A2)
#define READING                (A6)
#define ESC_BUTON              (A7)    
#define ENTER                  digitalRead(UP_BUTTON)== LOW && digitalRead(DWN_BUTTON)==LOW
#define SUS                    digitalRead(UP_BUTTON) == LOW
#define JOS                    digitalRead(DWN_BUTTON) == LOW  
#define ESC                    esc<200               
/* offsets into the EEPROM storage for calibration */
#define MASTER_CAL_EEP_ADDR     0
#define SWR_OFFSET_ADDR         4
#define DBM_OFFSET_ADDR         10
#define HELLO_EEP_ADDR          73
#define MAX_SpanNum             10
/*to switch on/off various clocks*/
#define SI_CLK0_CONTROL         16     
#define SI_CLK1_CONTROL         17
#define SI_CLK2_CONTROL         18
#define IF_FREQ                 (24996500l)
#define MODE_SWR                0
#define MODE_SNA                1
#define MODE_VOB                2

uint32_t xtal_freq_calibrated   = 27000000l;
unsigned long centerFreq        =14000000l;                 
unsigned long spanFreq          =25000000l;                     
long SpanNum[] = {25000000l,10000000l, 5000000l, 1000000l, 500000l,200000l, 100000l, 50000l, 20000l,10000l, 5000l};
int selectedSpan                = 0;              //initial span 25MHz
unsigned long mode              = MODE_SWR;
char b[32], c[32], a[32], e[32]; 

unsigned long frequency         = 10000000l;
int dbmOffset;                 
float swrOffset_calibrated;
float volts; 
float working_dBm;
int Data;
bool menuON  = true;
bool AUTO = true, SINGLE=false;                   //Mod scanare Automat sau Single 

/************************************************************/
void active_delay(int delay_by){
  unsigned long timeStart = millis();
  while (millis() - timeStart <= delay_by) {
      //Background Work      
  }
}

/*******************************************************/
void SetOscilators(long newfreq){
long local_osc;
long adc_preview_freq = 0;  
int adc_previewMode = 0;

  if (newfreq < 440000l) newfreq = 440000l;               //minim 440KHz
  
  if (newfreq < 150000000l){
    if (newfreq < 50000000l) local_osc = newfreq + IF_FREQ;   
    else local_osc = newfreq - IF_FREQ;
  } 
  else {
    newfreq = newfreq / 3;
    local_osc = newfreq - IF_FREQ/3;
  }
  
  if (adc_preview_freq != newfreq || adc_previewMode != mode){
    switch(mode){
    case MODE_SNA:
      si5351aSetFrequency_clk2(local_osc);
      si5351aOutputOff(SI_CLK1_CONTROL);
      si5351aOutputOff(SI_CLK0_CONTROL);
      break;
    case MODE_VOB:
      si5351aSetFrequency_clk2(local_osc);
      si5351aOutputOff(SI_CLK1_CONTROL);        
      si5351aSetFrequency_clk0(newfreq);
      break;
    default:
      si5351aSetFrequency_clk2(local_osc);  
      si5351aSetFrequency_clk1(newfreq);
      si5351aOutputOff(SI_CLK0_CONTROL);        
    }      
    adc_preview_freq = newfreq;
    adc_previewMode = mode;
  }     
}
/********** Sistem Initialization **************/
void setup() {
  GLCD.Init();            
  GLCD.SelectFont(System5x7);
  b[0]= 0;
  Wire.begin();
  analogReference(DEFAULT);
  pinMode(UP_BUTTON, INPUT_PULLUP);
  pinMode(DWN_BUTTON, INPUT_PULLUP);
/******************* Initializare DUMP EEPROM **************************/
  Data = EEPROM.read(HELLO_EEP_ADDR);                                //citeste mesajul "Hello"
  if(Data !=73){
     EEPROM.put(MASTER_CAL_EEP_ADDR, 27000073);
     EEPROM.put(SWR_OFFSET_ADDR, 0.0);
     EEPROM.write(HELLO_EEP_ADDR, 73);
     EEPROM.put(DBM_OFFSET_ADDR, -85);
  }
  /******************************************************************/ 
  EEPROM.get(MASTER_CAL_EEP_ADDR, xtal_freq_calibrated);
  EEPROM.get(SWR_OFFSET_ADDR, swrOffset_calibrated);
  EEPROM.get(DBM_OFFSET_ADDR, dbmOffset);                                       
  mode = MODE_SWR;                                                 //initial mode SWR

  /*daca se apasa butonul ENTER la pornire intra in Calibrare*/
  if(ENTER_BUTTON()) SettingsMenu();                        
  else  ResetMainScreen();                                       
  
  si5351aOutputOff(SI_CLK0_CONTROL);                              //initializare Si5351 CLK0
  centerFreq = 14000000l;
  SetOscilators(centerFreq);                                      //seteaza oscilatoarele
}
int adc_preview = 0;

/****************************************************************************************
/********************** Bucla principala de program ************************************
****************************************************************************************/
void loop(){
  MainMenu();                                               //afisare meniu principal    
  int adc_read = analogRead(READING);                              //citeste dBm 
 /******************Citeste tasta ESC *********************/
  int esc = analogRead(ESC_BUTON);                          //citeste butonul ESC
  if(ESC){                                                  //daca ESC este apasat...  
      delay(500);
      ResetMainScreen();
 }
  /**********************************************************/
  if (adc_read != adc_preview){
    SetOscilators(centerFreq);
    Bargraf();
    adc_preview = adc_read;                                 //actualizare citire ADC
  }  
  delay(50);   
}
